package com.UdeA.Ciclo3.Models;

import javax.persistence.*;
import java.util.List;
public enum Role {

    ADMINISTRADOR,OPERATIVO;

}